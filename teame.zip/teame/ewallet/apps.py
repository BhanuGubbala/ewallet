from django.apps import AppConfig


class EwalletConfig(AppConfig):
    name = 'ewallet'

