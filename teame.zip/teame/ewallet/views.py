'''from django.shortcuts import render
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.template.loader import render_to_string
from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'index.html')
def index2(request):
		return render(request,'index2.html')
def index1(request):
		return render(request,'index1.html')
def index3(request):
		return render(request,'index3.html')	
def index5(request):
		return render(request,'index5.html')	
def index8(request):
		return render(request,'index8.html')
def login(request):
	return render(request,'login.html')
def home(request):
	return render(request,'home.html')'''
from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'index.html')
def index2(request):
		return render(request,'index2.html')
def index1(request):
		return render(request,'index1.html')
def index3(request):
		return render(request,'index3.html')	
def index5(request):
		return render(request,'index5.html')	
def index8(request):
		return render(request,'index8.html')
def login(request):
	return render(request,'login.html')
def home(request):
	return render(request,'home.html')
