'''from django.db import models
#/models.py
from django.contrib.auth.models import User
# Create your models here.

class UserProfileInfo(models.Model):
	username = models.CharField(max_length=30, default='')
	password = models.CharField(max_length=10,default='')
	email = models.CharField(max_length=30, default='@gmail.com')
def __str__(self):
  return self.UserProfileInfo.username, self.UserProfileInfo.password'''
from django.db import models

# Create your models here.
