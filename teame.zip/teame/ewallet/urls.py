from django.urls import path
from . import views
#from django.contrib.auth import views

urlpatterns = [
		path('', views.index, name='index'),
		path('index2', views.index2,name='index2'),
		path('index1', views.index1,name='index1'),
		path('index3',views.index3,name='index3'),
		path('index5',views.index5,name='index5'),	
		path('index3',views.index3,name='index3'),
		path('index8', views.index8,name='index8'),	
		path('index', views.index,name='index'),
]


